Basecamps
=========

Projects used to be called _Basecamps_, but not anymore. See the [Projects](https://github.com/basecamp/bc3-api/blob/master/sections/projects.md#projects) section for documentation.
